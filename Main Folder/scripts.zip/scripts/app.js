(function() {

    'use strict';

    angular.module('formlyApp', ['formly', 'formlyBootstrap']);

})();